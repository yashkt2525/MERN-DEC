const MoviePage = () => {
  return <div>MoviePage</div>;
};

export default MoviePage;
